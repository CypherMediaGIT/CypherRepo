class BotGroupMissionRAD: CustomMission
{
	
	void BotGroupMissionRAD() {}
	
	
	// Config bots
	vector BotSpawnPoint = "7837.91 246.012 5826.46";				// set the point of the spawn bot	
	
	protected int m_botAcuracy = 10;											// Setting up the accuracy of the bot (the higher the number, the more often the bot will miss)
	
	protected int BotSolderCountMin = 3;  										// assign the minimum number of bots
	protected int BotSolderCountMax = 4;										// assign the maximum number of bots
	
	protected int botLootCountMin = 5; 											// assign a minimum amount of loot to the bot
	protected int botLootCountMax = 15; 										// assign the maximum amount of loot from the bot
	
	protected float Zone_Radius = 1100;											// The trigger radius on the player for the appearance of bots
	
	protected bool isUseCheckPoints = true;										// ask whether checkponints are used (true = used, false = not used)
	protected bool isBotKaratist = false;										// false = Bots will spawn with weapons     true = they fight with their fists
	protected bool onRespawnBot = true;											// Turning the bot's respawn (true = on, false = off)
	protected bool canUseTrigger = true;										// Use the trigger (true = on, false = off) if the trigger is not used bots will die immediately after the server is launched
	protected int m_respawnTime = 5;											// The respawn time of the bot (Default 30 minutes)
	
	protected bool canBotSpawned = true;										// Don't change!!!!!!!
	
	// ------------------------------- End of the config  ------------------------------------------ //
	
	
	// Arrays with loot and clothes
	// If you don't need any type just leave an empty Array ... for example ---> TStringArray OtherEquip = {""};
	ref TStringArray Shirt = {"GorkaEJacket_Autumn", "GorkaEJacket_Flat", "GorkaEJacket_PautRev", "GorkaEJacket_Summer"}; 					//Add the top clothing
	ref TStringArray Jeans = {"GorkaPants_Autumn", "GorkaPants_Flat", "GorkaPants_PautRev", "GorkaPants_Summer"}; 							//Add the jeans clothing
	ref TStringArray Shoes = {"TTSKOBoots", "WorkingBoots_Beige", "CombatBoots_Beige", "CombatBoots_Black", "CombatBoots_Brown"};			//Add the boots
	ref TStringArray BackPack = {"CoyoteBag_Brown", "CoyoteBag_Green", "HuntingBag", "TortillaBag", "WaterproofBag_Green"};					//Add the bag type
	ref TStringArray Vest = {"HighCapacityVest_Black", "HighCapacityVest_Olive", "HuntingVest", "PlateCarrierVest", "UKAssVest_Camo"};		//Add the vest type
	ref TStringArray Helm = {"GorkaHelmet", "Mich2001Helmet", "MotoHelmet_Black", "PumpkinHelmet", "SkateHelmet_Black"};					//Add the helmet type
	ref TStringArray Gloves = {"WorkingGloves_Beige", "WorkingGloves_Black", "NBCGlovesGray", "OMNOGloves_Brown", "SurgicalGloves_Blue"};	//Add the gloves type
	ref TStringArray OtherEquip = {"CivilianBelt", "MilitaryBelt"};																			//Add an extra element of clothing, it can be anything	
	
	ref TStringArray RandomLoot = {"SardinesCan", "SodaCan_Cola", "SodaCan_Kvass", "Rice", "Rope", "Screwdriver", "AmmoBox_545x39_20Rnd"};  //Add to the mash any loot, the number is not limited
	ref TStringArray MeleeWeap = {"WoodAxe", "FirefighterAxe", "Shovel", "Pickaxe"}; 														//Add melee weapons
	
	// -------------------------------- end of loot arrays  -------------------------------------------------------//

	protected EntityAI itemEnt;				// Don't change!!!!

	// The function of creating checkpoints (add/edit in your custom checkpoints here)
	void AddCeckPoint(SurvivorBotBase m_BotSolder)
	{
		m_BotSolder.SetUseCheckpoint(); // We don't touch this line!
		
		m_BotSolder.AddCheckpoint("7840.82 245.912 5802.26");
		m_BotSolder.AddCheckpoint("7855.61 246.264 5837.86");
		m_BotSolder.AddCheckpoint("7846.56 246.577 5868.63");
		m_BotSolder.AddCheckpoint("7816.1 246.386 5886");
		m_BotSolder.AddCheckpoint("7792.75 246.362 5866.84");
		m_BotSolder.AddCheckpoint("7817.31 246.318 5870.86");
		m_BotSolder.AddCheckpoint("7841.16 245.912 5809.38");	
	}
	// ---------------------------------- End of checkpoint function  -------------------------------------- /	
	

	
	
	// Bot weapon function (you can add 7 in-hand weapons, enter at your discretion)
	void createWeapFromBot(SurvivorBotBase m_BotSolder)
	{
		int randomWeapon = Math.RandomInt(1, 7);
			
		switch( randomWeapon )
		{	
			case 1: 
			{
				m_BotSolder.AddWeapon("M4A1"); 				//Weapon
				m_BotSolder.AddWeaponAtt("M4_RISHndgrd");	//Attachment 1
				m_BotSolder.AddWeaponAtt("M4_MPBttstck");	//Attachment 2
				m_BotSolder.AddWeaponAtt("ACOGOptic");		//Attachment 3
				break;
				//We do attachments as needed, and there are no automatic weapons stores.
			}
				
			case 2: 
			{
				m_BotSolder.AddWeapon("AKM");
				m_BotSolder.AddWeaponAtt("AK_WoodBttstck");
				m_BotSolder.AddWeaponAtt("AK_WoodHndgrd");
				break;
			}
				
			case 3: 
			{
				m_BotSolder.AddWeapon("AKM");
				m_BotSolder.AddWeaponAtt("AK_WoodBttstck");
				m_BotSolder.AddWeaponAtt("AK_WoodHndgrd");
				break;
			}
				
			case 4: 
			{
				m_BotSolder.AddWeapon("SVD");
				break;
			}
				
			case 5: 
			{
				m_BotSolder.AddWeapon("M4A1"); 	
				m_BotSolder.AddWeaponAtt("M4_RISHndgrd");	
				m_BotSolder.AddWeaponAtt("M4_MPBttstck");	
				m_BotSolder.AddWeaponAtt("ACOGOptic");		
				break;
			}
				
			case 6: 
			{
				m_BotSolder.AddWeapon("AKM");
				m_BotSolder.AddWeaponAtt("AK_WoodBttstck");
				m_BotSolder.AddWeaponAtt("AK_WoodHndgrd");
				break;
			}
				
			case 7: 
			{
				m_BotSolder.AddWeapon("AKM");
				m_BotSolder.AddWeaponAtt("AK_WoodBttstck");
				m_BotSolder.AddWeaponAtt("AK_WoodHndgrd");
				break;
			}
		}		
	}
	// ----------------------------- End of weapon-making function ------------------------------------- //
	
	// The function of the bot spawns (there is nothing to change!!!)
	void createBotUnit()
	{
		private SurvivorBotBase m_BotSolder;
		
		float bspX = BotSpawnPoint[0];
		float bspY = BotSpawnPoint[2];
		
		vector botSpPos = Vector(bspX + Math.RandomInt(1, 5), BotSpawnPoint[1], bspY + Math.RandomInt(1, 5));
				
		m_BotSolder = SurvivorBotBase.Cast(GetGame().CreateObject("BotM_Mirek", botSpPos));
		
		
		if (isBotKaratist)
		{
			m_BotSolder.GetHumanInventory().CreateInHands(MeleeWeap.GetRandomElement());
		}
		else
		{
			createWeapFromBot(m_BotSolder);
		}
		
		m_BotSolder.GetInventory().CreateInInventory(Shirt.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(Jeans.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(Shoes.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(BackPack.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(Vest.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(Helm.GetRandomElement());
		m_BotSolder.GetInventory().CreateInInventory(Gloves.GetRandomElement());			
		m_BotSolder.GetInventory().CreateInInventory(OtherEquip.GetRandomElement());
			
		int rndLootCnt = Math.RandomInt(botLootCountMin, botLootCountMax);
			
		for (int i = 0; i < rndLootCnt; i++)
		{
			itemEnt = m_BotSolder.GetInventory().CreateInInventory(RandomLoot.GetRandomElement());
			if (itemEnt)
			{
				int rndHlt = Math.RandomInt(55,100);
				itemEnt.SetHealth("","",rndHlt);
			}
		}

		m_BotSolder.SetAcuracy(m_botAcuracy);
		
		if (isUseCheckPoints) 
			AddCeckPoint(m_BotSolder);
	
		
		if (m_BotSolder.IsAlive() && m_BotSolder && onRespawnBot)
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(respawnBotUnitRAD, m_respawnTime * 60000, true, m_BotSolder);
	}
	// ----------------------------- End of the Bot Spawn Function ------------------------------------- //
	
	// ----------------------------- Bot Respawn Function ----------------------------------------//
	private void respawnBotUnitRAD(SurvivorBotBase m_Bot)
	{
		if (onRespawnBot && m_Bot.IsRespawned())
		{
			if (!m_Bot.IsAlive())
			{
				Print("The Enemy AI is Returning!" + m_Bot);
				createBotUnit();
				m_Bot.SetRespawned( false );
			}		
		}		
	}
	// ----------------------------- End of feature ----------------------------------------//
	

	
	
	// The bot group spaWn function
	void spawnBotGroup()
	{
		int rndBotGrpCnt = Math.RandomInt(BotSolderCountMin, BotSolderCountMax);
		Print("Enemy AI Has Returned! Count " + rndBotGrpCnt);
		for (int a = 0; a < rndBotGrpCnt; a++)
		{
			createBotUnit();
		}	
	}
	// --------------------------------------- End of group spawn function  --------------------------------------- //
	
	// Trigger function on the player
	void TriggerPlayersRAD()
	{  
		ref array<Man> players = new array<Man>;
		GetGame().GetPlayers( players );
				
		if (canBotSpawned)
		{	
			for ( int u = 0; u < players.Count(); u++ )
			{
					
				PlayerBase player;
				Class.CastTo(player, players.Get(u));
				vector pos = player.GetPosition();
				float dist = vector.Distance( pos, BotSpawnPoint );
				
				if ( dist < Zone_Radius ) 
				{
					spawnBotGroup();
					GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).Remove(TriggerPlayersRAD);			
				} 
			}
		}
	} 
	// --------------------------------------- End of trigger function  --------------------------------------- //
	
	// We call this feature in initBotMissions.c
	void StartMissionAI()
	{
		Print("Watch out for Enemy AI!");
		if (canUseTrigger)
		{
			GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(TriggerPlayersRAD, 5000, true);			
		}
		else
		{
			spawnBotGroup();
		}
	}
	
}