#include "$CurrentDir:\\mpmissions\\Expansion.EnochGloom\\BotMissions\\BotGroupMissionRAD.c" 


class initBotMissions
{
	void initBotMissions() {};
	
	void runBotMissions()
	{
		// Launch of the RAD mission--------------------------------------------
		BotGroupMissionRAD onMissionRAD = new BotGroupMissionRAD();
		onMissionRAD.StartMissionAI();	
		//---------------------------------------------------------------
			
	}
		
}
