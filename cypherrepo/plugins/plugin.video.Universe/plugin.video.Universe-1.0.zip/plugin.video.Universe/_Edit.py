import xbmcaddon

MainBase = 'http://universerepo.esy.es/home.xml'
addon = xbmcaddon.Addon('plugin.video.Universe')