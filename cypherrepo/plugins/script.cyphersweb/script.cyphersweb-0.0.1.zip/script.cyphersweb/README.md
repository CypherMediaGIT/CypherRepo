script.cyphersweb
=================

Cyphers WebViewer addon for Kodi - browse web pages from Kodi with a sad text interface
-------------------------------------------------------------------------------
This addon allows viewing web pages in a sequential text view. It supports playing video links via the youtube-dl module.
It doesn't support javascript or any sort of formatting and not all web pages will display in a useful manner.
It can however be useful for simple browsing or accessing a video when all else fails.

If you want to ensure you are using the latest version of the addon you can install my 
