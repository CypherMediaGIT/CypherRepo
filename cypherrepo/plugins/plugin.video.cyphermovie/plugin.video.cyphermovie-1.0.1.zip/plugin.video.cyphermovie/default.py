import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,net,base64,urlresolver,jsunpack
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.cyphermovie'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
nextp = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'next.png'))
metaset = selfAddon.getSetting('enable_meta')

def CATEGORIES():
	addDir('[COLOR cyan]Recent Additions[/COLOR]','http://www.hulumovies.org/page/1/',1,icon,fanart)
	addDir('[COLOR cyan]Search[/COLOR]','http://www.hulumovies.org',3,icon,fanart)
	#addDir('Genres','http://www.hulumovies.org',4,icon,fanart)
        addDir('Years','http://www.hulumovies.org',5,icon,fanart)
	GENRES()
             		
def GETMOVIES(url,name):
        currenturl=url
        cp = url.split('/')[-2]
        cpstr = '/page/'+cp+'/'
	metaset = selfAddon.getSetting('enable_meta')
	link = cleanHex(net.http_GET(url).content)
	if 'PELICULAS'in link:
                match=re.compile('PELICULAS(.+?)<div id="paginador">',re.DOTALL).findall(link)[0]
                match=re.compile('class="item">(.+?)<div class="boxinfo">',re.DOTALL).findall(match)
        else:match=re.compile('class="item">(.+?)<div class="boxinfo">',re.DOTALL).findall(link)
	itemcount=len(match)
        for data in match:
                name=re.compile('alt="(.+?)"').findall(data)[0]
                url=re.compile('<a href="(.+)"').findall(data)[0]
                iconimage=re.compile('<img src="(.+?)"').findall(data)[0]
                try:addMeta(name,url,100,iconimage,itemcount,'page',isFolder=False)
                except:pass
        try:
                np = int(cp)+1
                np = '/page/'+str(np)+'/'
                if np in link:
                        nextpage=currenturl.replace(cpstr,np)
                        addDir('Next Page >>',nextpage,1,nextp,fanart)
        except:pass
	if metaset=='true':setView('movies', 'MAIN')
	else: xbmc.executebuiltin('Container.SetViewMode(50)')

def PLAYLINK(name,url,iconimage,page):
        link = net.http_GET(url).content
        if 'IFRAME SRC' in link:
                host=re.compile('<IFRAME SRC="(.+?)"').findall(link)[0]
                link = net.http_GET(host).content
                js=re.compile("<script type='text/javascript'>(.+?)</script>",re.DOTALL).findall(link)[0]
                unjs=jsunpack.unpack(js)
                url=re.compile('file:"(.+?)"').findall(unjs)[0]
        elif 'file:' in link:
                url=re.compile('file:"(.+?)"').findall(link)[0]
        else:url=re.compile('<iframe src="(.+?)" scrolling="no"').findall(link)[0]
        url=url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36'
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	xbmc.Player().play(url, liz, False)
	return ok
	
def SEARCH():
        search_entered =''
        title='[COLOR blue]Search[/COLOR]'
        keyboard = xbmc.Keyboard(search_entered,title)
        keyboard.doModal()
        if keyboard.isConfirmed():search_entered = keyboard.getText().replace(' ','+')
        if len(search_entered)>1:
                url = 'http://www.hulumovies.org/?s='+search_entered
                GETMOVIES(url,name='')
        else:quit()

def GENRES():
        link = net.http_GET('http://www.hulumovies.org').content
        genres=re.compile('<li class="cat-item cat-item-.+?"><a href="(.+?)" >(.+?)</a> <span>.+?</span>').findall(link)
        for url, name in genres:
                if name != 'All Years':
                        name=name.replace('&amp;','&')
                        if not '0' in name:
                                url=url+'page/1/'
                                addDir(name,url,1,icon,fanart) 
      
def YEARS():
        link = net.http_GET('http://www.hulumovies.org').content
        genres=re.compile('<li class="cat-item cat-item-.+?"><a href="(.+?)" >(.+?)</a> <span>.+?</span>').findall(link)
        for url, name in genres:
                if name != 'All Years':
                        name=name.replace('&amp;','&')
                        if '0' in name:
                                url=url+'page/1/'
                                addDir(name,url,1,icon,fanart) 
		 
def cleanHex(text):
        def fixup(m):
                text = m.group(0)
                if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
                else: return unichr(int(text[2:-1])).encode('utf-8')
        try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
        except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
			       
	return param

def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name,url,mode,iconimage,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
	liz.setProperty('fanart_image', fanart)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addMeta(name,url,mode,iconimage,itemcount,page='',isFolder=False):
	if metaset=='true':
	  if not 'COLOR' in name:
	    splitName=name.partition('(')
	    simplename=""
	    simpleyear=""
	    if len(splitName)>0:
		simplename=splitName[0]
		simpleyear=splitName[2].partition(')')
	    if len(simpleyear)>0:
		simpleyear=simpleyear[0]
	    meta = mg.get_meta('movie', name=simplename ,year=simpleyear)
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+urllib.quote_plus(page)
	    ok=True
	    if meta['cover_url'] == '':iconimage=iconimage
	    else: iconimage=meta['cover_url']
	    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	    liz.setInfo( type="Video", infoLabels=meta )
	    contextMenuItems = []
	    if not meta['trailer']=='':contextMenuItems.append(('Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 6, 'url':meta['trailer']})))
	    contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
	    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
	    if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', meta['backdrop_url'])
	    else: liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder,totalItems=itemcount)
	    return ok
	else:
	    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&page="+urllib.quote_plus(page)
	    ok=True
	    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	    liz.setInfo( type="Video", infoLabels={ "Title": name } )
	    liz.setProperty('fanart_image', fanart)
	    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
	    return ok

def TRAILER(url):
        xbmc.executebuiltin("PlayMedia(%s)"%url)
        
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if selfAddon.getSetting('auto-view')=='true':
                xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting(viewType) )

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None

try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: page=urllib.unquote_plus(params["page"])
except: pass
mg = eval(base64.b64decode('bWV0YWhhbmRsZXJzLk1ldGFEYXRhKHRtZGJfYXBpX2tleT0iZDk1NWQ4ZjAyYTNmMjQ4MGE1MTg4MWZlNGM5NmYxMGUiKQ=='))
if mode==None or url==None or len(url)<1: CATEGORIES()
elif mode==1: GETMOVIES(url,name)
elif mode==2: GETLINKS(url,name,iconimage)
elif mode==3: SEARCH()
elif mode==4: GENRES()
elif mode==5: YEARS()
elif mode==6: TRAILER(url)
elif mode==100: PLAYLINK(name,url,iconimage,page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
