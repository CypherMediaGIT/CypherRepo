# -*- coding: utf-8 -*-
# --[ YourSports v1.0 ]--|--[ From JewBMX & Tempest ]--
# IPTV Indexer made just for the one site as of now.

import re, os, sys, urllib, base64
from resources.lib.modules import client
from resources.lib.modules import control


class Cypheriptv:
    def __init__(self):
        self.list = []
        self.base_link = 'http://yoursports.stream'
        self.base2_link = 'http://'
        self.uAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
        self.headers = {'User-Agent': self.uAgent, 'Referer': self.base_link}

    def root(self):
        channels = [        
            ('ABC', '/ing/abc', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/ABC.png?raw=true'),
            ('ABC Australia (Wait a few Seconds to Load)', '/ing/tvx2?ch=abcaustralia', 'https://uploads-ssl.webflow.com/5c635e8d9b911131172d6b70/5c635e8d9b9111ee342d6c7a_ABC_Australia_logo-p-800.png'),
            ('ABC News', '/ing/abcnews', 'https://i.imgur.com/V8eTp2V.png'),
            ('ABC News Australia', '/ing/tvx2?ch=abcnewsaustralia', 'https://www.abc.net.au/cm/lb/8212704/data/news-logo2017-data.png'),
            ('AL Jazeera', '/ing/aljazeera', 'http://www.egypttoday.com/images/larg/13842.jpg'),
            ('Atlanta TV', '/ing/atlanta', 'https://fontmeme.com/images/ATLANTA-SET-IN-CABERNET-FONT.png'),
            ('BET', '/ing/bet', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/Bet.png?raw=true'),
            ('My TV Buffalo', '/ing/buffalo', 'https://upload.wikimedia.org/wikipedia/en/d/d0/Wnyo_mntv.PNG'),
            ('BUZZR', '/ing/buzzr', 'https://i.vimeocdn.com/video/556352061.webp?mw=1000&mh=562&q=70'),
            ('CBS (Wait a few Seconds to Load)', '/ing/cbs', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/CBS.png?raw=true'),
            ('CBS News', '/ing/cbsn', 'https://religionnews.com/wp-content/uploads/2019/04/webRNS-CBS_News_logo1-040519.jpg'),
            ('Cheddar', '/ing/cheddar', 'https://www.multichannel.com/.image/t_share/MTU1MDE1MDczNjU0NDQ5Mjcw/cheddar-logo-16x9.png'),
            ('Cheddar BIG News', '/ing/cheddarnews', 'https://talkingbiznews.com/wp-content/uploads/2018/04/Screen-Shot-2018-04-17-at-5.38.40-PM-300x272.png'),
            ('Classic Arts', '/ing/tvx2?ch=classicarts', 'https://pbs.twimg.com/profile_images/708574672888135680/reNxGF3z_400x400.jpg'),
            ('Classic TV 4U', '/ing/tvx2?ch=classic4u', 'https://mytvtogo.net/wp-content/uploads/2018/11/Network_ClassicTV4U_1280x720.jpg'),          
            ('CMC', '/ing/cmc', 'http://www.vector-logo.net/logo_preview/ai/c/CMC_LOGO.png'),
            ('CMT', '/ing/cmt', 'http://allvectorlogo.com/img/2016/07/country-music-television-cmt-logo.png'),
            ('Comet', '/ing/comet', 'https://cdn.collider.com/wp-content/uploads/2019/08/comet-tv-logo.png'),           
            ('CON TV', '/ing/contv', 'https://pbs.twimg.com/profile_images/1044272252072521728/IWUQk2nK_400x400.jpg'),
            ('DABL', '/ing/tvx2?ch=dabl', 'https://pmcvariety.files.wordpress.com/2019/06/dabl-herologo1-e1560713804358.jpg'),
            ('Documentaries', '/ing/documentary', 'https://images-platform.99static.com/fQD1-6iYPBe3x1rzBnNHZUutz54=/500x500/top/smart/99designs-contests-attachments/24/24032/attachment_24032543'),
            ('Documentaries 4U', '/ing/tvx2?ch=documentaries4u', 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRBkNrw9it_EnQTC2DB2n3yV4xrVfD8nn_luakJZmUWMhYdg4uj'),
            ('FailArmy', '/ing/tvx2?ch=failarmy', 'https://vignette.wikia.nocookie.net/logopedia/images/c/c8/FailArmy_logo_.jpg/revision/latest/scale-to-width-down/340?cb=20150126211049'),
            ('Film Detective', '/ing/filmdetective', 'https://nscreenmedia.com/wp-content/uploads/The-Film-Detective-logo.png'),
            ('FreeForm', '/ing/freeform', 'https://www.pngkey.com/png/full/321-3212066_freeform-blue-black-sanstagline-freeform-logo-transparent.png'),       ('FX', '/ing/fx', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/FX.png?raw=true'),
            ('FXX', '/ing/fxx', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/FXX.png?raw=true'),
            ('FXM', '/ing/fxm', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/FXX.png?raw=true'),            
            ('Garage TV', '/ing/garagetv', 'https://www.pngkey.com/png/detail/139-1393003_el-garage-tv-garage-tv-logo.png'),
            ('History 2', '/ing/history2', 'https://assets.change.org/photos/3/nl/bo/KNnLbOykNAOPeaR-400x400-noPad.jpg?1527644200'),
            ('House Channel', '/ing/HORnews', 'http://hcfama.org/sites/default/files/state_house_banner_1.png'),
            ('ID', '/ing/tvx2?ch=id', 'https://www.pngkit.com/png/full/442-4421623_a-kid-to-kill-for-investigation-discovery-logo.png'),            
            ('InfoWars', '/ing/infowars', 'http://www.infowarsshop.com/assets/images/infowarssquaresticker2.jpg'),
            ('David Knight (InfoWars)', '/ing/infowardk', 'https://avatars.brighteon.com/d7cf4433-f647-409f-8529-caaaf63f0475'),
            ('InfoWar War Room', '/ing/infowarroom', 'https://images.infowarsmedia.com/images/5cc0970f7e6a4e0026b181dd'),
            ('Law And Crime', '/ing/lawandcrime', 'https://image.xumo.com/v1/channels/channel/9999320/248x140.png?type=channelTile'),
            ('MTV', '/ing/mtv', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/MTV.png?raw=true'),
            ('Nat Geo People', '/ing/natgeopeople', 'https://i0.wp.com/unifistreamyx.info/wp-content/uploads/2015/07/NatGeo_People_logo-628x353.gif'),
            ('Nat Geo Wild', '/ing/natgeowild', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/Nat%20Geo%20Wild.png?raw=true'),
            ('National Geographic', '/ing/natgeo', 'https://blog.nationalgeographic.org/wp-content/uploads/2019/08/NG_Logo-1140x450.jpg'),
            ('Nature Vision', '/ing/po?ch=naturevision', 'https://www.ses.com/sites/default/files/styles/card/public/2018-01/Nature%20Vision%20Logo_1.png?itok=LGdA3q_m'),
            ('NBC (Wait a few Seconds to Load)', '/ing/nbc', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/NBC.png?raw=true'),
            ('News Net', '/ing/newsnet', 'https://yournewsnet.com/wp-content/uploads/2017/12/Newsnet-sm-1.jpg'),
            ('NewsMax Tv', '/ing/newsmax', 'https://www.multichannel.com/.image/t_share/MTU0MDYzODE1OTgwOTUxMjkx/newsmax-logojpg.jpg'),
            ('Newsy', '/ing/newsy', 'https://www.multichannel.com/.image/t_share/MTYzOTI5MDY4NjI5MTQxMzI5/newsy-logo.jpg'),
            ('Paramont Network', '/ing/paramount', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/Paramount%20Network.png?raw=true'),
            ('POP', '/ing/poptv', 'https://image.roku.com/developer_channels/prod/e148f89d6265fe0b45a7e68c7ba4e92880d8fcf7ab6bac8cd397065cade013c1.png'),      
            ('RetroTV', '/ing/retrotv', 'https://cdn5.vectorstock.com/i/1000x1000/56/64/retro-tv-logo-design-flat-icon-vector-8035664.jpg'),
            ('RT America', '/ing/rtusanews', 'https://pbs.twimg.com/profile_images/1167911174/logo_RTamerica_white.jpg'),
            ('ScreamFest', '/ing/screamfest', 'https://i0.wp.com/thehorrorsyndicate.com/wp-content/uploads/2016/10/FEA-3.png?fit=610%2C345'),
            ('The Shopping Channel', '/ing/qvc', 'http://dawnchubai.com/wordpress/wp-content/uploads/2017/04/TSC_Logo_Primary_SM_RGB-21.jpg'),
            ('Tv Land', '/ing/tvland', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/TV%20Land.png?raw=true'),
            ('VH1', '/ing/tvx2?ch=vh1', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/VH1.png?raw=true'),
            ('Washington Post Live', '/ing/tvx2?ch=wpnews', 'https://pbs.twimg.com/profile_images/785948379041918977/2-arwrVt.jpg'),
            ('Weather Nation', '/ing/weathernation', 'https://is4-ssl.mzstatic.com/image/thumb/Purple123/v4/4f/ae/54/4fae5431-6273-6d15-930f-a216d1d1f02c/AppIcon-0-1x_U007emarketing-0-0-85-220-0-7.png/1200x630wa.png'),
            ('WGN9', '/ing/wgn', 'https://tribwgntv.files.wordpress.com/2019/01/wgnnewlogo.jpg?quality=85&strip=all'),
            ('WHDH 7 BOSTON', '/ing/cwboston', 'https://i.ytimg.com/vi/gejwOB2luO8/hqdefault.jpg'),
            ('ACC Network', '/ing/acc', 'https://cdn1.thecomeback.com/wp-content/uploads/sites/94/2016/07/acc_network.png'),
            ('BEK East', '/ing/tvx2?ch=bekeast', 'https://pbs.twimg.com/profile_images/1029091222810316800/xCXtS7g1_400x400.jpg'),
            ('BEK West', '/ing/tvx2?ch=bekwest', 'https://pbs.twimg.com/profile_images/1029091222810316800/xCXtS7g1_400x400.jpg'),
            ('CCX Sports', '/ing/ccxsports', 'https://pbs.twimg.com/profile_images/809859306954723328/ldxBUVVT.jpg'),
            ('ESPN', '/ing/espn', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/ESPN.png?raw=true'),
            ('ESPN 2', '/ing/espn2', 'https://github.com/jewbmx/resource.images.studios.white/blob/master/resources/ESPN.png?raw=true'),
            ('ESPN Longhorn', '/ing/lhn', 'https://texassports.com/images/2013/7/29/longhorn-network-1000x540.jpg?width=1128&height=635&mode=crop'),
            ('ESPN News', '/ing/espnnews', 'https://upload.wikimedia.org/wikipedia/commons/3/31/Espnnews.png'),
            ('ESPN U', '/ing/espnu', 'http://p-img.movetv.com/cms/images/a5e621a17fba73a2dd3f8c0304168aebc9253dd4.jpg'),
            ('ESPN SEC Network', '/ing/sec', 'https://www.multichannel.com/.image/t_share/MTU0MDY0OTQ4Nzc2NzQwNjAz/sec-network-logojpg.jpg'),            
            ('FOX Sports News', '/ing/fsnews', 'http://store-images.s-microsoft.com/image/apps.64293.9007199267003755.bfdca1b8-de6f-4813-a156-c79a99c7ef99.5aaea734-f974-4c58-a6a7-a9c726e668c9'),
            ('NBC Golf Channel', '/ing/golf', 'https://www.golfchannel.com/sites/default/files/new_golf_channel_logo_304.jpg'),
            ('Lacrosse Network (Wait a few Seconds to Load)', '/ing/c?ch=lacrosse', 'https://yt3.ggpht.com/a/AGF-l79fL2RBHZvBXAOOSegaVhZNytK6ESlCWBf4=s900-c-k-c0xffffffff-no-rj-mo'),
            ('MLB Network', '/ing/mlbn', 'https://upload.wikimedia.org/wikipedia/en/thumb/a/ac/MLBNetworkLogo.svg/280px-MLBNetworkLogo.svg.png'),
            ('Olympic Channel', '/ing/olympic', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 2', '/ing/olympic2', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 3', '/ing/olympic3', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 4', '/ing/olympic3', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 4', '/ing/olympic4', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 5', '/ing/olympic5', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('Olympic Channel 6', '/ing/olympic6', 'https://images-na.ssl-images-amazon.com/images/I/517OUKvP9kL._SX450_.png'),
            ('ONE Golf', '/ing/tvx2?ch=onegolf', 'http://onegolftv.com/wp-content/uploads/2018/08/onegolf-HD-oneline-01b.jpg'),
            ('Red Bull TV', '/ing/redbull', 'https://www.red24management.com/wp-content/uploads/2016/10/Becky-Ives-Red-Bull-TV.jpg'),
            ('Sports Grid', '/ing/sportsgrid', 'https://cdn.newswire.com/files/x/cb/d0/0cbe6c1785c364c7756a54ea4b57.jpg'),
            ('Stadium Sports (Wait a few Seconds to Load)', '/ing/stadium', 'https://s23455.pcdn.co/wp-content/uploads/2018/08/stadium-logo-640.jpeg'),
            ('Tennis Channel', '/ing/tennis', 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Tennis_Channel_logo.svg/220px-Tennis_Channel_logo.svg.png'),
            ('TENNIS CHANNEL: THE T', '/ing/thet', 'https://www.multichannel.com/.image/t_share/MTU0MDYzODk5MTkxMjg4OTE0/tennis-channel-logo-400x300jpg.jpg'),
            ('TENNIS PLUS 1', '/ing/tennisplus?g=1', 'https://mark.trademarkia.com/logo-images/the-tennis-channel/t-tennis-channel-plus-86418209.jpg'),
            ('TENNIS PLUS 2', '/ing/tennisplus?g=2', 'https://mark.trademarkia.com/logo-images/the-tennis-channel/t-tennis-channel-plus-86418209.jpg'),
            ('XCORP TV', '/ing/xcorps', 'https://images.all-free-download.com/images/graphiclarge/x_corp_143718.jpg')            

           
        ]
        for channel in channels:
            self.list.append({'name': channel[0], 'url': self.base_link + channel[1], 'image': channel[2], 'action': 'CypherPlay'})
        self.addDirectory(self.list)
        return self.list

    def play(self, url):
        try:
            stream = client.request(url)
            try:
                link = re.compile('var mustave = atob\((.+?)\)').findall(stream)[0]
            except:
                link = re.compile('<iframe frameborder=0 height=100% width=100% src="(.+?php)"', re.DOTALL).findall(stream)[0]
                link = client.request(link)
                link = re.compile('var mustave = atob\((.+?)\)').findall(link)[0]
            link = base64.b64decode(link)
            if link.startswith('/'):
                link = self.base_link + link
            link = '%s|User-Agent=%s&Referer=%s' % (link, self.uAgent, url)
            control.execute('PlayMedia(%s)' % link)
        except:
            return

    def addDirectory(self, items, queue=False, isFolder=True):
        if items is None or len(items) is 0:
            control.idle()
            sys.exit()
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()
        for i in items:
            try:
                name = i['name']
                if i['image'].startswith('http'):
                    thumb = i['image']
                elif artPath is not None:
                    thumb = os.path.join(artPath, i['image'])
                else:
                    thumb = addonThumb
                item = control.item(label=name)
                if isFolder:
                    url = '%s?action=%s' % (sysaddon, i['action'])
                    try:
                        url += '&url=%s' % urllib.quote_plus(i['url'])
                    except Exception:
                        pass
                    item.setProperty('IsPlayable', 'false')
                else:
                    url = '%s?action=%s' % (sysaddon, i['action'])
                    try:
                        url += '&url=%s' % i['url']
                    except Exception:
                        pass
                    item.setProperty('IsPlayable', 'true')
                    item.setInfo("mediatype", "video")
                    item.setInfo("audio", '')
                item.setArt({'icon': thumb, 'thumb': thumb})
                if addonFanart is not None:
                    item.setProperty('Fanart_Image', addonFanart)
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
            except Exception:
                pass
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)
