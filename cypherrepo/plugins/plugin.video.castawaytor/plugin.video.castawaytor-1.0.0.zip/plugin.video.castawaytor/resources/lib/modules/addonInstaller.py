# -*- coding: utf-8 -*-
import os
import xbmc, xbmcaddon
import control
import urllib
import zipfile

from dialogProgress import DialogProgress
from fileUtils import getFileContent, clearDirectory
from regexUtils import findall

PACKAGE_DIR = "special://home/addons/packages/"
INSTALL_DIR = "special://home/addons/"


DICT = {
        'youtube' : 'http://cypher-media.com/plugin.video.youtube-5.5.0.zip',
        'quasar'  : 'https://github.com/scakemyer/plugin.video.quasar/releases/download/v0.9.78/plugin.video.quasar-0.9.78.zip'}

def get_addons():
    a = [('YouTube', 'youtube', 'plugin.video.youtube', 'https://github.com/CypherMediaGIT/CypherRepo/blob/master/cypherrepo/plugins/plugin.video.youtube/icon.png?raw=true'),
	    ('Quasar', 'quasar', 'plugin.video.quasar', 'https://github.com/scakemyer/plugin.video.quasar/blob/master/icon.png?raw=true')]
    return a

def install(key):
    entry = DICT[key]
    return _install_addon(entry)

def _install_addon(url):
    ri = AddonInstaller()
    compressed = ri.download(url)
    if compressed:
        addonId = ri.install(compressed)
        if addonId:
            xbmc.sleep(100)
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.sleep(100)
            try:
                _N_ = xbmcaddon.Addon(id=addonId)
                control.infoDialog('Addon installed')
                return True
            except:
                pass
    return False

def isInstalled(addonId):
    try:
        _N_ = xbmcaddon.Addon(id=addonId)
        return True
    except:
        return False


class AddonInstaller:
    
    def download(self, url, destination=PACKAGE_DIR):
        try:
            dlg = DialogProgress()
            dlg.create('Castaway Torrent - Installing external addon')
            destination = xbmc.translatePath(destination) + os.path.basename(url)
            def _report_hook(count, blocksize, totalsize):
                percent = int(float(count * blocksize * 100) / totalsize)
                dlg.update(percent, url, destination)
            fp, _ = urllib.urlretrieve(url, destination, _report_hook)
            return fp
        except:
            pass
        dlg.close()
        return ""

    def extract(self, fileOrPath, directory):
        try:               
            if not directory.endswith(':') and not os.path.exists(directory):
                os.mkdir(directory)
            zf = zipfile.ZipFile(fileOrPath)
            for _, name in enumerate(zf.namelist()):
                if name.endswith('/'):
                    path = os.path.join(directory, name)
                    if os.path.exists(path):
                        clearDirectory(path)
                    else:
                        os.makedirs(path, 0777)
                else:
                    outfile = open(os.path.join(directory, name), 'wb')
                    outfile.write(zf.read(name))
                    outfile.flush()
                    outfile.close()
            return zf.filelist

        except:
            pass

        return None
                        
    def install(self, filename):
        destination = xbmc.translatePath(INSTALL_DIR)
        files = self.extract(filename, destination)
        if files:
            addonXml = filter(lambda x: x.filename.endswith('addon.xml'), files)
            if addonXml:
                path = os.path.join(destination, addonXml[0].filename)
                content = getFileContent(path)
                addonId = findall(content, '<addon id="([^"]+)"')
                if addonId:
                    return addonId[0]
        return None
    
