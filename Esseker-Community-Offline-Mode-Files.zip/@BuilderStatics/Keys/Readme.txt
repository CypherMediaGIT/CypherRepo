This mod is not meant to be used on a server. It is for use while editing only, and will break all proxy
items in the world when enabled, meaning all furniture in buildings will not render. 

If you're reading this in the future and using COT to edit on a server, simply disable signature checks for 
the server while you're editing, and only load this mod when editing. Don't edit on your live server, use a 
test server on your local machine for that. 