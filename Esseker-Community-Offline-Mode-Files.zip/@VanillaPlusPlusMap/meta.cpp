protocol = 1;
publishedid = 1623711988;
name = "VanillaPlusPlusMap";
timestamp = 5248977215706932581;
