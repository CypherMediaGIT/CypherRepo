#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Esseker\\core\\ModuleManager.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Esseker\\core\\StaticFunctions.c"

#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Esseker\\core\\CommunityOfflineClient.c"
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Esseker\\core\\CommunityOfflineServer.c"