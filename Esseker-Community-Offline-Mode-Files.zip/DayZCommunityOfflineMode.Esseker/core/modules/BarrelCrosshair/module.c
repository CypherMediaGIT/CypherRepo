/*
    Define used for optional compilations
*/
#define MODULE_BARREL_CROSSHAIR

/*
    Include of all .c files that belong to this module
*/

#ifdef COM_MODULES_OLDLOADING
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Esseker\\core\\modules\\BarrelCrosshair\\gui\\BarrelCrosshair.c"
#endif

