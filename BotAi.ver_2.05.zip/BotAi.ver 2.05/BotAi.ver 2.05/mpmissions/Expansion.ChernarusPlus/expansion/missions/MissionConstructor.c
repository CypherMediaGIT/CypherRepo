class COMMissionConstructor: ExpansionMissionConstructor
{
	override void RegisterMissions( out TTypenameArray missions )
	{
		super.RegisterMissions( missions );
	}
}